# :christmas_tree:  AdventOfCode2017 :christmas_tree: 
This is where it all begins...
My attempt at [AoC2017](http://adventofcode.com/2017). 
I'll try and finish as many challenges I can.

A little bit in R, a little bit in Python, whatever I feel like on the day.
